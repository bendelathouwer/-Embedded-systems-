/*BSP*/
#include "stm32746g_discovery_lcd.h"
/*STemWin*/
#include "GUI.h"
#include "WM.h"
#include "DIALOG.h"
WM_HWIN CreateWindow(void);
